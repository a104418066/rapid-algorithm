
tic
% 读取数据
data = readmatrix('20240523d.xlsx');
S1_Joy1 = data(7140:7340, 4);
S2_Joy2 = data(7140:7340, 8);
sampling_interval = 2e-8; % 采样间隔（秒）
% 计算采样频率
sampling_frequency = 1 / sampling_interval;
% 设定截止频率
cutoff_frequency = 1e6; % Hz
% 计算归一化的截止频率
normalized_cutoff_frequency = cutoff_frequency / (sampling_frequency/2);
% 对数据进行低通滤波
S1_Joy = lowpass(S1_Joy1, normalized_cutoff_frequency, sampling_frequency);
S2_Joy = lowpass(S2_Joy2, normalized_cutoff_frequency, sampling_frequency);
specific_points = [1:length(S1_Joy)];
time = [(0:length(specific_points)-1) * sampling_interval]*10e5;
figure(1)
plot(time,S1_Joy);
hold on;
plot(time,S2_Joy);
hold off;
xlabel('时间/μs');
ylabel('电压/V');
figure(2)
plot(S1_Joy);
hold on;
plot(S2_Joy);
hold off;
xlabel('采样点数');
ylabel('电压/V');
% 计算整体的相关系数
overall_pearson_r = corr(S1_Joy, S2_Joy);
disp(['计算的Pearson r：', num2str(overall_pearson_r)]);
overall_coupla_r = copula(S1_Joy,S2_Joy);
disp(['最优Copula类型为：',  overall_coupla_r{3} ,' Copula函数']);
disp(['计算的Copula Kendall秩相关系数 ：',  num2str(overall_coupla_r{1})]);
disp(['计算的Copula Spearman秩相关系数：', num2str(overall_coupla_r{2})]);