%% 拟合2维copula函数并选择最优的
function overall_pearson_r=copula(X,Y) 

% %% 计算偏度和峰度
% score_skewness_X=skewness(X);   % 计算X的偏度
% score_skewness_Y=skewness(Y);   % 计算Y的偏度
% 
% score_kurtosiss_X=kurtosis(X);  % 计算单产数据的峰度
% score_kurtosiss_Y=kurtosis(Y);  % 计算价格数据的峰度

%% 调用ksdensity函数分别计算原始样本X和Y处的核分布估计值
U = ksdensity(X,X,'function','cdf');
V = ksdensity(Y,Y,'function','cdf');

%% 求Copula中参数的估计值【5种分布的参数极大似然估计】
% 调用copulafit函数估计二元Gaussian-Copula中的参数
rho_Gaussian = copulafit('Gaussian',[U(:), V(:)]);
% 调用copulafit函数估计二元t-Copula中的参数
[rho_t,nuhat] = copulafit('t',[U(:), V(:)]);
% 调用copulafit函数估计二元Frank-Copula中的参数
rho_Frank = copulafit('Frank',[U(:), V(:)]);
% 调用copulafit函数估计二元Gumbel-Copula中的参数
rho_Gumbel = copulafit('Gumbel',[U(:), V(:)]);
% 调用copulafit函数估计二元Clayton-Copula中的参数
rho_Clayton = copulafit('Clayton',[U(:), V(:)]);

% %% 计算5种copula的尾部相关系数
% %下尾相关系数
% lama1_Gaussian=0;
% lama1_t=2-2*tcdf(sqrt(nuhat+1)*sqrt(1-rho_t(1,2))/sqrt(1+rho_t(1,2)),nuhat+1);
% lama1_Frank=0;
% lama1_Gumbel=0;
% lama1_Clayton=2^(-1/rho_Clayton);
% 
% %上尾相关系数
% lama2_Gaussian=0;
% lama2_t=2-2*tcdf(sqrt(nuhat+1)*sqrt(1-rho_t(1,2))/sqrt(1+rho_t(1,2)),nuhat+1);
% lama2_Frank=0;
% lama2_Gumbel=2-2^(1/rho_Gumbel);
% lama2_Clayton=0;

% %% 求5种copula的AIC和BIC值【判定最优Copula的标准之一，AIC和BIC值越小对应的Copula拟合效果越好】
% % 计算Gaussian-Copula对应的AIC和BIC值
% parameter_Gaussian=1;
% rows=size(X,1);
% PDF_Gaussian=copulapdf('Gaussian',[U(:), V(:)],rho_Gaussian);
% AIC_gaussian=-2*sum(log(PDF_Gaussian))+2*parameter_Gaussian;
% BIC_gaussian=-2*sum(log(PDF_Gaussian))+log(rows)*parameter_Gaussian;
% 
% % 计算t-Copula对应的AIC和BIC值
% parameter_t=2; %还有个自由度参数，所以是2
% PDF_t=copulapdf('t',[U(:), V(:)],rho_t,nuhat);
% AIC_t=-2*sum(log(PDF_t))+2*parameter_t;
% BIC_t=-2*sum(log(PDF_t))+log(rows)*parameter_t;
% 
% % 计算Frank-Copula对应的AIC和BIC值
% parameter_Frank=1;
% PDF_Frank=copulapdf('Frank',[U(:), V(:)],rho_Frank);
% AIC_Frank=-2*sum(log(PDF_Frank))+2*parameter_Frank;
% BIC_Frank=-2*sum(log(PDF_Frank))+log(rows)*parameter_Frank;
% 
% % 计算Gumbel-Copula对应的AIC和BIC值
% parameter_Gumbel=1;
% PDF_Gumbel=copulapdf('Gumbel',[U(:), V(:)],rho_Gumbel);
% AIC_Gumbel=-2*sum(log(PDF_Gumbel))+2*parameter_Gumbel;
% BIC_Gumbel=-2*sum(log(PDF_Gumbel))+log(rows)*parameter_Gumbel;
% 
% % 计算Clayton-Copula对应的AIC和BIC值
% parameter_Clayton=1;
% PDF_Clayton=copulapdf('Clayton',[U(:), V(:)],rho_Clayton);
% AIC_Clayton=-2*sum(log(PDF_Clayton))+2*parameter_Clayton;
% BIC_Clayton=-2*sum(log(PDF_Clayton))+log(rows)*parameter_Clayton;
% 
% [value1,serial1]=min([AIC_gaussian AIC_t AIC_Frank AIC_Gumbel AIC_Clayton]);  %value是最小值，serial是最小值对应的序号
% % 从AIC结果选择最小的value，作为最合适的选择
% % 本案例选择第2个 t copula为最合适的联合分布
% 
% [value2,serial2]=min([BIC_gaussian BIC_t BIC_Frank BIC_Gumbel BIC_Clayton]);  %value是最小值，serial是最小值对应的序号
% % 从BIC结果选择最小的value，作为最合适的选择
% % 本案例选择第2个 t copula为最合适的联合分布

%% 5种分布与经验分布的平方欧氏距离【判定最优Copula的标准之一，平方欧氏距离越小对应的Copula拟合效果越好】
% 调用ecdf函数求X和Y的经验分布函数
[fx, Xsort] = ecdf(X);
[fy, Ysort] = ecdf(Y);
% 调用spline函数，利用样条插值法求原始样本点处的经验分布函数值
U = spline(Xsort(2:end),fx(2:end),X);
V = spline(Ysort(2:end),fy(2:end),Y);
% 定义经验Copula函数C(u,v)
C = @(u,v)mean((U <= u).*(V <= v));

% 通过循环计算经验Copula函数在原始样本点处的函数值
CUV = zeros(size(U(:)));
for i=1:numel(U)
    CUV(i) = C(U(i),V(i));
end
% 计算二元Gaussian-Copula函数在原始样本点处的函数值
C_Gaussian = copulacdf('Gaussian',[U(:), V(:)],rho_Gaussian);
% 计算二元t-Copula函数在原始样本点处的函数值
C_t = copulacdf('t',[U(:), V(:)],rho_t,nuhat);
% 计算二元Frank-Copula函数在原始样本点处的函数值
C_Frank = copulacdf('Frank',[U(:), V(:)],rho_Frank);
% 计算二元Gumbel-Copula函数在原始样本点处的函数值
C_Gumbel = copulacdf('Gumbel',[U(:), V(:)],rho_Gumbel);
% 计算二元Clayton-Copula函数在原始样本点处的函数值
C_Clayton = copulacdf('Clayton',[U(:), V(:)],rho_Clayton);

% 计算5种copula的平方欧氏距离
d2_Gaussian = (CUV-C_Gaussian)'*(CUV-C_Gaussian);
d2_t = (CUV-C_t)'*(CUV-C_t);
d2_Frank = (CUV-C_Frank)'*(CUV-C_Frank);
d2_Gumbel = (CUV-C_Gumbel)'*(CUV-C_Gumbel);
d2_Clayton = (CUV-C_Clayton)'*(CUV-C_Clayton);

[value3,serial3]=min([d2_Gaussian d2_t d2_Frank d2_Gumbel d2_Clayton]);  %value是最小值，serial是最小值对应的序号
% 从结果选择最小的d，作为最合适的选择
% 本案例选择第2个 t copula为最合适的联合分布

switch serial3
    %% 求Copula中Kendall秩相关系数和Spearman秩相关系数
    case 1 
        % 调用copulastat函数求二元Gaussian-Copula对应的Kendall秩相关系数
        Kendall = copulastat('Gaussian',rho_Gaussian);
        Kendall = Kendall(1,2);
        % 调用copulastat函数求二元Gaussian-Copula对应的Spearman秩相关系数
        Spearman = copulastat('Gaussian',rho_Gaussian,'type','Spearman');
        Spearman = Spearman(1,2);
        name = 'Gaussian';
    case 2
        % 调用copulastat函数求二元t-Copula对应的Kendall秩相关系数
        Kendall = copulastat('t',rho_t);
        Kendall = Kendall(1,2);
        % 调用copulastat函数求二元t-Copula对应的Spearman秩相关系数
        Spearman = copulastat('t',rho_t,nuhat,'type','Spearman');
        Spearman = Spearman(1,2);
        name = 't';
    case 3
        % 调用copulastat函数求二元Frank-Copula对应的Kendall秩相关系数
        Kendall = copulastat('Frank',rho_Frank);
        % 调用copulastat函数求二元Flayton-Copula对应的Spearman秩相关系数
        Spearman = copulastat('Frank',rho_Frank,'type','Spearman');
        name = 'Frank';
    case 4
        % 调用copulastat函数求二元Gumbel-Copula对应的Kendall秩相关系数
        Kendall = copulastat('Gumbel',rho_Gumbel);
        % 调用copulastat函数求二元Gumbel-Copula对应的Spearman秩相关系数
        Spearman = copulastat('Gumbel',rho_Gumbel,'type','Spearman');
        name = 'Gumbel';
    case 5
        % 调用copulastat函数求二元Clayton-Copula对应的Kendall秩相关系数
        Kendall = copulastat('Clayton',rho_Clayton);
        % 调用copulastat函数求二元Clayton-Copula对应的Spearman秩相关系数
        Spearman= copulastat('Clayton',rho_Clayton,'type','Spearman');
        name = 'Clayton';
end

overall_pearson_r=[Kendall,Spearman,{name}];
end


